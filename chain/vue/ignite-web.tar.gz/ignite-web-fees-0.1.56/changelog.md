# Changelog

## `v0.1.55`

### Features:

- added `no-legacy-stdTx` [flag](https://github.com/tendermint/vue/commit/01a05ee0106c87824f157b7bda6361cff0218bed)

### Changed:

- updated codeowners

## `v0.1.54`

### Changed:

- updated dependencies
- updated generated cosmos-sdk code

## `v0.1.53`

### Features:
- new storybook package

### Changed:

- updated generated cosmos-sdk code

## `v0.1.52`

### Changed:

- added refresh for offline clients

## `v0.1.51`

### Features:

- added offline client support
- auto-updating balance in `SpTokenSend`

## `v0.1.50`

### Changed:
- updated cosmjs wallet method signatures
