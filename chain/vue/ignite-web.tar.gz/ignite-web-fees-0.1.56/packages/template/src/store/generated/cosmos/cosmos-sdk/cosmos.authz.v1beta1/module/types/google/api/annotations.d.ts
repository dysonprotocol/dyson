export declare const protobufPackage = "google.api";
