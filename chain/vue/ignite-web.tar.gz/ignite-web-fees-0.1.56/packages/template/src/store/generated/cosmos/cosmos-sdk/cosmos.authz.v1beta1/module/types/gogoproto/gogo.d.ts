export declare const protobufPackage = "gogoproto";
