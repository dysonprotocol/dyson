/* eslint-disable */
export const protobufPackage = 'cosmos_proto';
